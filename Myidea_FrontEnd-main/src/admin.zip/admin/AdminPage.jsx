import { useEffect, useState } from 'react'
import ResourceAdmin from './ResourceAdmin'
import LoginForm from './LoginForm'
import { getToken, clearToken } from './auth'

// ---- Each student edits this part: names of THEIR models and fields ----
const productFields = [
	{ name: 'title', type: 'text' },
	{ name: 'description', type: 'textarea' },
	{ name: 'price', type: 'number' },
	{ name: 'stock', type: 'number' },
	{ name: 'category', type: 'select', optionsFrom: 'categories', optionLabel: 'name' },
	{ name: 'images', type: 'images' },
	{ name: 'isActive', type: 'checkbox' },
]
const productColumns = [
	{ key: 'title' },
	{ key: 'price' },
	{ key: 'stock' },
	{ key: 'category', render: (p) => p.category?.name },
	{ key: 'images', render: (p) => p.images?.[0] && <img src={p.images[0].url} alt="" width="48" /> },
]

const categoryFields = [
	{ name: 'name', type: 'text' },
	{ name: 'slug', type: 'text' },
	{ name: 'parent', type: 'select', optionsFrom: 'categories', optionLabel: 'name' },
]
const categoryColumns = [{ key: 'name' }, { key: 'slug' }, { key: 'parent', render: (c) => c.parent?.name }]
// -------------------------------------------------------------------------

export default function AdminPage() {
	const [tab, setTab] = useState('products')
	const [loggedIn, setLoggedIn] = useState(() => Boolean(getToken()))

	// authFetch sends a "logout" event when the server answers 401 (for example, the token expired)
	useEffect(() => {
		const onLogout = () => setLoggedIn(false)
		window.addEventListener('logout', onLogout)
		return () => window.removeEventListener('logout', onLogout)
	}, [])

	function logout() {
		clearToken()
		setLoggedIn(false)
	}

	if (!loggedIn) return <LoginForm onLogin={() => setLoggedIn(true)} />

	return (
		<div>
			<nav style={{ display: 'flex', gap: 8 }}>
				<button onClick={() => setTab('products')}>Products</button>
				<button onClick={() => setTab('categories')}>Categories</button>
				<button onClick={logout} style={{ marginLeft: 'auto' }}>Log out</button>
			</nav>
			{tab === 'products' && (
				<ResourceAdmin resource="products" title="Products" fields={productFields} columns={productColumns} />
			)}
			{tab === 'categories' && (
				<ResourceAdmin resource="categories" title="Categories" fields={categoryFields} columns={categoryColumns} />
			)}
		</div>
	)
}